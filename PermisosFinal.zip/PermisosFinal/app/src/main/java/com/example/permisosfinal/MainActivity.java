package com.example.permisosfinal;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import android.Manifest;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.content.pm.PackageManager;

public class MainActivity extends AppCompatActivity {
    Button btn, btn2, btn3, btn4, btn5, btn6, btn7;
    private static final int REQUISITO_LLAMADA = 1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        btn = findViewById(R.id.bntMostrrarContacto);
        btn2 = findViewById(R.id.btnBuscarGoogle);
        btn3 = findViewById(R.id.btnMostrarTelefonoConNumero);
        btn4 = findViewById(R.id.btnLLamarNumeroDirectamente);
        btn5 = findViewById(R.id.btnMostrarMapa);
        btn6 = findViewById(R.id.btnAbrirCamara);
        btn7 = findViewById(R.id.btnEnviarSms);

        btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i = new Intent(Intent.ACTION_VIEW, Uri.parse("content://contacts/people/"));
                startActivity(i);
            }
        });

        btn2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i = new Intent(Intent.ACTION_VIEW, Uri.parse("https://www.google.com"));
                startActivity(i);
            }
        });

        btn3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(Intent.ACTION_DIAL, Uri.parse("tel:123456789"));
                startActivity(i);
            }
        });

        btn4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (ContextCompat.checkSelfPermission(MainActivity.this, Manifest.permission.CALL_PHONE) != PackageManager.PERMISSION_GRANTED) {
                    // Si no se ha otorgado el permiso, solicítalo
                    ActivityCompat.requestPermissions(MainActivity.this, new String[]{Manifest.permission.CALL_PHONE}, REQUISITO_LLAMADA);
                } else {
                    // Permiso otorgado, realiza la llamada
                    llamarAlTelefono();
                }
            }
        });

        btn5.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(Intent.ACTION_VIEW,
                        Uri.parse("geo:39.41,-5.56?q=71,Calle Obreros Jeronimo Y fidel jardon  Talayuela"));
                startActivity(i);
            }
        });

        btn6.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent("android.media.action.IMAGE_CAPTURE");
                startActivity(i);
            }
        });

        btn7.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(Intent.ACTION_SENDTO, Uri.parse("smsto:254254254"));
                i.putExtra("sms_body", "Texto a enviar");
                startActivity(i);
            }
        });
    }

    @Override
    public void onRequestPermissionsResult(int requisitosCodigo, String[] permisos, int[] resultadosAceptados) {
        super.onRequestPermissionsResult(requisitosCodigo, permisos, resultadosAceptados);
        if (requisitosCodigo == REQUISITO_LLAMADA) {
            if (resultadosAceptados.length > 0 && resultadosAceptados[0] == PackageManager.PERMISSION_GRANTED) {
                llamarAlTelefono();
            } else {
                AlertDialog.Builder b=new AlertDialog.Builder(this);
                b.setMessage("No se ha otrogado el permiso");
                b.setTitle("Info permiso");
                b.show();
            }
        }
    }

    private void llamarAlTelefono() {
        Intent i = new Intent(Intent.ACTION_CALL, Uri.parse("tel:123456789"));
        startActivity(i);
    }
}
