package com.example.imc;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

public class MainActivity extends AppCompatActivity {
    Button btn2;
    EditText etName,etPeso,etAltura;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        btn2=findViewById(R.id.btn_Calcular);
        etName=findViewById(R.id.editTextNombre);
        etPeso=findViewById(R.id.editTextPesos);
        etAltura=findViewById(R.id.editTextAltura);
    }

    public void calculator(View view) {
        Intent i=new Intent(getApplicationContext(),MainActivity2.class);
        i.putExtra("nombre",etName.getText().toString());
        i.putExtra("altura",etAltura.getText().toString());
        i.putExtra("peso",etPeso.getText().toString());
        String alt= String.valueOf(etAltura.getText());
        String peso= String.valueOf(etPeso.getText());
        double imc= Double.parseDouble(peso)/Math.pow(Double.parseDouble(alt),2);
        float imc2 = (Math.round(((Float.parseFloat(peso) /
                (Float.parseFloat(alt) * Float.parseFloat(alt)))*100)))/100f;
        i.putExtra("imc",String.valueOf(imc2));
        startActivity(i);
    }
    public void comrprobarRanfo(){

    }
}