package com.example.imc;

import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.TextView;

public class MainActivity2 extends AppCompatActivity {
    TextView t1;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);
        t1=findViewById(R.id.tvResultado);
        Bundle b=getIntent().getExtras();
        String nom=b.getString("nombre");
        String alt=b.getString("altura");
        String peso=b.getString("peso");
        String imc=b.getString("imc");
        t1.setText("Nombre: " + nom + "\n"+
                   "Altura: " + alt + "\n"+
                   "Peso: " + peso + "\n"+
                   "Tú IMC es de : " + imc+"\n");
    }
}