package com.example.listapersonalizada;

public class Pelis {
    public String titulo;
    public int imagen;
    public Pelis(String tit,int img){
        this.titulo=tit;
        this.imagen=img;
    }

}
