package com.example.enivardatosentreactividades;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

public class MainActivity extends AppCompatActivity {
    Button btn,btn3;
    EditText etNom,et2Ape;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        btn=findViewById(R.id.button);
        btn3=findViewById(R.id.btn3);
        btn.setText("Aceptar");
        etNom=findViewById(R.id.editTextText);
        et2Ape=findViewById(R.id.editTextText2);
    }

    public void pasar(View v){
        Intent i=new Intent(this, MainActivity2.class);
        startActivity(i);
    }

    public void enviar(View view) {
        btn.setText("");
        Intent i=new Intent(getApplicationContext(), MainActivity2.class);
        i.putExtra("nombre",etNom.getText().toString());
        i.putExtra("apellido",et2Ape.getText().toString());
        i.putExtra("control",btn3.getText().toString());
        startActivity(i);
    }

}