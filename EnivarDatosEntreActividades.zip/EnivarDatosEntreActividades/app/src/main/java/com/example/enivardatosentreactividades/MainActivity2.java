package com.example.enivardatosentreactividades;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

public class MainActivity2 extends AppCompatActivity {

    Button btn;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);
        btn=findViewById(R.id.button2);
        Bundle extra=getIntent().getExtras();
        String contra=extra.getString("control");
        if(contra!="") {
        String nom=extra.getString("nombre");
        String Custer=extra.getString("apellido");
            Toast.makeText(getApplicationContext(), "Nombre: " + nom + "Apellidos: " + Custer, Toast.LENGTH_LONG).show();
        }
    }
    public void enviable2(View v){
        Intent i=new Intent(this, MainActivity.class);

        startActivity(i);
    }
}