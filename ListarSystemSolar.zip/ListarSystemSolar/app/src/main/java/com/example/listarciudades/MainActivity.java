package com.example.listarciudades;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {
    ListView l1;
    Button btn;
    ArrayList<String> br=new ArrayList<>();
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        l1=findViewById(R.id.listaCiudades);
        btn=findViewById(R.id.btnM);
        ArrayAdapter<CharSequence> adapter=ArrayAdapter.createFromResource(this,R.array.planetas_sistema_solar, android.R.layout.simple_list_item_1);
        l1.setAdapter(adapter);
        l1.setChoiceMode(ListView.CHOICE_MODE_MULTIPLE);
        l1.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                String pal=parent.getItemAtPosition(position).toString();
                br.add(pal);
            }

        });
        btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                for (int i = 0; i < br.size(); i++) {
                    Toast.makeText(MainActivity.this, br.get(i).toString(), Toast.LENGTH_SHORT).show();

                }

            }
        });
    }
}