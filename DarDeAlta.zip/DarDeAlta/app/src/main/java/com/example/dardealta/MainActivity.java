package com.example.dardealta;

import androidx.activity.result.ActivityResult;
import androidx.activity.result.ActivityResultCallback;
import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {
    Button btn;
    TextView etDatos,tvHist;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        btn = findViewById(R.id.button);
        etDatos = findViewById(R.id.textView);
        tvHist = findViewById(R.id.tvHistorial);
        Intent i = new Intent(MainActivity.this, MainActivity2.class);
        ActivityResultLauncher<Intent> lanzador = registerForActivityResult(new ActivityResultContracts.StartActivityForResult(), new ActivityResultCallback<ActivityResult>() {
            @Override
            public void onActivityResult(ActivityResult result) {
                Intent data = result.getData();
                String nombre = data.getExtras().getString("nombre");
                String apellidos = data.getExtras().getString("apellido");

                if (tvHist.getText().toString().trim().equals("No hay ningun usuario dado de alta")) {
                    tvHist.setText("Nombre: " + nombre + "\n" +
                            "Apellidos: " + apellidos + "\n");
                } else {
                    tvHist.setText(tvHist.getText() + "Nombre: " + nombre + "\n" +
                            "Apellidos: " + apellidos + "\n");
                }


            }
        });
        btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                lanzador.launch(i);
            }
        });

    }
}