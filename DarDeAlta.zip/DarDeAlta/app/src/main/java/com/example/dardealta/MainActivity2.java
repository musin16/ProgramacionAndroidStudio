package com.example.dardealta;

import androidx.activity.result.ActivityResult;
import androidx.activity.result.ActivityResultCallback;
import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity2 extends AppCompatActivity {
    EditText etName,etApel;
    Button btn;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);
        etName=findViewById(R.id.editTextNombre);
        etApel=findViewById(R.id.editTextApellidos);
        btn=findViewById(R.id.button2);
        ActivityResultLauncher<Intent> lanzar=registerForActivityResult(new ActivityResultContracts.StartActivityForResult(), new ActivityResultCallback<ActivityResult>() {
            @Override
            public void onActivityResult(ActivityResult o) {

            }
        });
        btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i=new Intent(MainActivity2.this,MainActivity.class);
                i.putExtra("nombre",etName.getText().toString());
                i.putExtra("apellido",etApel.getText().toString());
                if(etName.getText().toString().isEmpty() || etApel.getText().toString().isEmpty()){
                    Toast.makeText(MainActivity2.this, "Introduzca correctamente los datos", Toast.LENGTH_SHORT).show();

                }else{
                    setResult(1,i);
                    finish();
                }
            }
        });

    }
}