package com.example.listarciudades;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
    ListView l1;
    TextView tv;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        l1=findViewById(R.id.listaCiudades);
        tv=findViewById(R.id.textView3);
        ArrayAdapter<CharSequence> adapter=ArrayAdapter.createFromResource(this,R.array.ciudades, android.R.layout.simple_list_item_1);
        l1.setAdapter(adapter);
        l1.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                String pal=parent.getItemAtPosition(position).toString();
                String habitantes=getResources().getStringArray(R.array.habitante)[position];
                tv.setText("");
                tv.setText("Habitantes: " + habitantes);
            }

        });
    }
}