package com.example.myapplication;

import static android.app.TimePickerDialog.*;

import androidx.appcompat.app.AppCompatActivity;

import android.app.DatePickerDialog;
import android.app.TimePickerDialog;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.TimePicker;

import java.net.DatagramPacket;
import java.sql.Date;
import java.util.Calendar;

public class MainActivity extends AppCompatActivity {

    EditText et1,et2;
    Button btn;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        et1=findViewById(R.id.editTextDate);
        et2=findViewById(R.id.editTextTime);

    }
    public void mostrarFecha(View v){
        DatePickerDialog r=new DatePickerDialog(this,new DatePickerDialog.OnDateSetListener() {


            @Override
            public void onDateSet(DatePicker view, int year, int month, int dayOfMonth ) {
                et1.setText(dayOfMonth+"/"+(month+1)+"/"+year);
            }
        },2021,2,20);
            r.show();
    }
    public void mostrarHora(View V){
        TimePickerDialog r=new TimePickerDialog(this, new TimePickerDialog.OnTimeSetListener() {
            @Override
            public void onTimeSet(TimePicker view, int hourOfDay, int minute) {
                et2.setText(hourOfDay+":"+minute);
            }
        },10,00,true);
        r.show();
    }
    public void mostrarFechaCalendar(View v){
        Intent i=new Intent(this, new MainActivity2().getClass());
        startActivity(i);
        /* Calendar c=Calendar.getInstance();
        int anio=c.get(Calendar.YEAR);
        int mes=c.get(Calendar.MONTH);
        int dia=c.get(Calendar.DAY_OF_MONTH);
        DatePickerDialog r=new DatePickerDialog(this, new DatePickerDialog.OnDateSetListener() {
            @Override
            public void onDateSet(DatePicker view, int year, int month, int dayOfMonth) {
                et1.setText(dayOfMonth+"/"+(month+1)+"/"+year);
            }
        },dia,mes,anio);
        r.show();*/
    }
}