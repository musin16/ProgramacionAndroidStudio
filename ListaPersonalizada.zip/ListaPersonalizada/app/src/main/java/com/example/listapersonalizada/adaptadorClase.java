package com.example.listapersonalizada;

import android.content.Context;
import android.content.res.Resources;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import java.util.ArrayList;

public class adaptadorClase extends BaseAdapter {
    ArrayList<Pelis> pelicula;
    Context contexto;
    public adaptadorClase(Context c){
        pelicula=new ArrayList<>();
        this.contexto=c;
        Resources res=c.getResources();
        String[] serie=res.getStringArray(R.array.titulo);
        int[] imagen={R.drawable.naruto,R.drawable.onepiece,
                R.drawable.naruto2,R.drawable.onepiece2,R.drawable.onepiece3};
        for (int i = 0; i < serie.length; i++) {
            pelicula.add(new Pelis(serie[i],imagen[i]));
        }
    }
    @Override
    public int getCount() {
        return pelicula.size();
    }

    @Override
    public Object getItem(int pos) {
        return pelicula.get(pos);
    }

    @Override
    public long getItemId(int pos) {
        return pos;
    }

    @Override
    public View getView(int i, View view, ViewGroup grupoVistas) {
        LayoutInflater inflar=(LayoutInflater) contexto.getSystemService
                (Context.LAYOUT_INFLATER_SERVICE);
        View vista=inflar.inflate(R.layout.filas,grupoVistas,false);
        TextView tv= vista.findViewById(R.id.textView);
        ImageView im= vista.findViewById(R.id.imageView);
        //Mostrar elemento definido en posicion
        Pelis p=pelicula.get(i);
        tv.setText(p.titulo);
        im.setImageResource(p.imagen);
        return vista;
    }

}
